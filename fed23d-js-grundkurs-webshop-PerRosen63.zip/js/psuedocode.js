//PSUEDOKOD
/**
 * xxx Skriv statisk HTML samt grundläggande CSS
 * 
 * 2. PRODUKTSEKTION
 * 
 * - gör array med objekt för varje produkt
 * 
 * - printa ut produkter inkl. plus- och minusknappar för varje produkt
 * 
 * - eventslyssnare på plus- och minusknappar
 * 
 * - "Osynligt" helgpåslag 15%
 * 
 * - Mängdrabatt/artikel, minst 10st 10%
 * 
 * 3. VARUKORG
 * 
 * - printa ut alla produkter med amount > 0
 * 
 * - summa
 * 
 * - Måndagsrabatt 03:00-10.00: 10 % på hela beställningen (synligt)
 * 
 * - Minst 15 varor = gratis frakt. 25kr + 10% av tot.bel.
 * 
 * - Uppdatera varukorg?
 * 
 * 4.FORMULÄR
 * 
 * - html
 * 
 * - conditional radiobuttons Faktura eller Kort
 * 
 * - validering
 * 
 * - event på Beställ-knapp som öppnar Bekräftelse-ruta
 * 
 * - Faktura högst 800kr
 * 
 * - Utgråad beställ-knapp
 * 
 * - Timeout efter 15 min med meddelande att beställaren är för långsam samt rensning av formulär. Start vid laddning av sida, klick i produktdelen eller klick i formulär. 
 * 
 * 5. SORTERA
 * 
 * - selectbox? radiobuttons?
 */